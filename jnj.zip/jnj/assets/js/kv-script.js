document.addEventListener('DOMContentLoaded', function () {
    var currentDate = new Date();
    var currdate = currentDate.getFullYear() + '-' + (currentDate.getMonth() + 1) + '-' + currentDate.getDate();
    var div_terms = $('.event-data').find('.item').last().offset();
    scroll_to_terms()
    $('#eventType').change(function () {
        $('.event-data').find('.item').addClass('d-none');
        $('.event-data').find('.default-btns').removeClass('d-none');
    });
    $('#eventType').change()

    $('#reset-event').hide();

    function scroll_to_terms() {
        if (div_terms) {
            $('.event-data').animate({scrollTop: div_terms.top}, "slow");
        }
    }

    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
        timeZone: 'EST',
        droppable: true,
        events: [{
            title: 'Training',
            start: '2020-12-07',
            end: '2020-12-08'
        },
            {
                title: 'A Long Event To Test Tooltip.',
                start: '2020-12-07',
                end: '2020-12-08'
            },
            {
                title: 'Training',
                start: '2020-12-17',
                end: '2020-12-17'
            },
            {
                title: 'Call',
                start: '2020-12-22',
                end: '2020-12-22',
                backgroundColor: '#c8102e',
                borderColor: '#c8102e'
            },
            {
                title: 'Training',
                start: '2020-12-24',
                end: '2020-12-24'
            },
            {
                title: 'Call',
                start: '2020-12-27',
                end: '2020-12-27',
                backgroundColor: '#c8102e',
                borderColor: '#c8102e'
            },
            {
                title: 'Call',
                start: '2020-12-29',
                end: '2020-12-29',
                backgroundColor: '#c8102e',
                borderColor: '#c8102e'
            },
            {
                title: 'Training',
                start: '2020-12-31',
                end: '2020-12-31',
            },

        ],
        eventClick: function (info) {
            var eventObj = info.event;
            if (eventObj.startStr && eventObj.title) {

                // var date = new Date(eventObj.start);
                // var dateFmt = date.getDate() + '-' + date.getMonth() + '-' + date.getFullYear();

                var date = eventObj.startStr;
                var type = eventObj.title.toLowerCase();
                if ($('.event-data').find('.' + type + '[data-date="' + date + '"]').length > 0) {
                    $('#eventType').val(type);
                    $('#eventType').change();

                    $('.event-data').find('.' + type).addClass('d-none');
                    $('.event-data').find('.' + type + '[data-date="' + date + '"]').removeClass('d-none')
                }
                // console.log(date);
                // console.log(type);
            }
        },
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
    });

    calendar.render();

    $('.carousel').carousel();

    $("#menu-toggle").click(function (e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });

    $("#eventType").change(function (e) {
        var selectedType = this.value;
        console.log(selectedType)
        if (selectedType == 'all') {
            $('.event-data').find('.item').removeClass('d-none');
            $('.webinar-session-carousel-head').find('.row').removeClass('reset')
            $('#reset-event').hide();
            $('.event-data').find('.item').addClass('d-none');
            $('.event-data').find('.default-btns').removeClass('d-none');
            scroll_to_terms()
        } else {
            $('.event-data').find('.default-btns').addClass('d-none');
            $('#reset-event').show();
            $('.webinar-session-carousel-head').find('.row').addClass('reset')
            $('.event-data').find('.item').addClass('d-none');
            $('.event-data').find('.' + selectedType).removeClass('d-none')
            scroll_to_terms()
        }
    });


    $('#reset-event').on('click', function (e) {
        e.preventDefault();
        $('#eventType').val('all');
        $('#eventType').change();
        // $(this).hide();
        scroll_to_terms();

    })
    $('#call-btn').on('click', function (e) {
        e.preventDefault();
        $('#eventType').val('call');
        $('#eventType').change();
    })

    $('#training-btn').on('click', function (e) {
        e.preventDefault();
        $('#eventType').val('training');
        $('#eventType').change();
    })


    $(document).on('mouseover', '.fc-daygrid-event-harness', function () {
        $(this).attr('data-tooltip',$(this).find('.fc-event-title').html());
    });

    $(document).on('change','#inputGroupSelectTime',function () {
        let txt = $("#inputGroupSelectTime option:selected").text();
        $('.session-content .time-zone').text(txt);
    });


    $(document).ready(function() {
        // Configure/customize these variables.
        var showChar = 102;  // How many characters are shown by default
        var ellipsestext = "...";
        var moretext = "Read More";
        var lesstext = "Read Less";


        $('.more').each(function() {
            var content = $(this).text();
            // console.log(content.replace(" ", "").length);

            if(content.length > showChar) {

                var c = content.substr(0, showChar);
                var h = content.substr(showChar, content.length - showChar);

                var html = c + '<span class="moreellipses">' + ellipsestext+ '&nbsp;</span><span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

                $(this).html(html);
            }

        });

        $(".morelink").click(function(){
            if($(this).hasClass("less")) {
                $(this).removeClass("less");
                $(this).html(moretext);
            } else {
                $(this).addClass("less");
                $(this).html(lesstext);
            }
            $(this).parent().prev().toggle();
            $(this).prev().toggle();
            return false;
        });
    });



});